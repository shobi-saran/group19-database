#Group19 Database Setup

This repository contains everything you need to recreate the Group19 PostgreSQL database for our class project.

##Project Structure

group19-database/
├── Data/
│ ├── SpotifyFeatures.csv
│ └── charts.csv
├── db/
│ └── schema.sql
└── setup.sql # main setup script for building the DB


used the following:
- PostgreSQL 18
- psql command line tool
- DataGrip
- Git

##Data Files
- SpotifyFeatures.csv https://drive.google.com/file/d/1jaEM2tlgIitOx3DQfiBOQPCR2km8tfHu/view?usp=sharing
- Charts.csv https://drive.google.com/file/d/1qusG-TZ_Zv07CkdGo3s-GasQTlxqRgoK/view?usp=sharing
