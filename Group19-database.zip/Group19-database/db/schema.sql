create table spotify_features
(
    genre            text,
    artist_name      text,
    track_name       text,
    track_id         text,
    popularity       integer,
    acousticness     double precision,
    danceability     double precision,
    duration_ms      integer,
    energy           double precision,
    instrumentalness double precision,
    key              text,
    liveness         double precision,
    loudness         double precision,
    mode             text,
    speechiness      double precision,
    tempo            double precision,
    time_signature   text,
    valence          double precision
);

alter table spotify_features
    owner to group19_user;

create table charts
(
    date           date,
    chart_rank     integer,
    song           text,
    artist         text,
    last_week      integer,
    peak_rank      integer,
    weeks_on_board integer
);

alter table charts
    owner to group19_user;


